<?php

return [
	"views" => [
		"listMonth"		=> "Month list",
		"listYear"		=> "Year list"
	]
];