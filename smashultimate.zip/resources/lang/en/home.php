<?php

return [
	"banner" => [
		"title"			=> "Welcome to SmashUltimate.fr",
		"description"	=> "The meeting point of the French competitive community on Super Smash Bros Ultimate"
	],
	"calendar"			=> "Quick Calendar",
	"twitter"			=> "Twitter",
	"twitch"			=> "Twitch live"
];