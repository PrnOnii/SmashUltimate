<?php

return [
	"meta" => [
		"description"	=> "Super Smash Bros Ultimate french competitive community's website",
		"title"			=> "French's competitive community's website"
	],

	"navbar" => [
		"home"			=> "Home",
		"calendar"		=> "Calendar",
		"vod"			=> "VODs",
		"ranking"		=> "Ranking",
		"map"			=> "Worldmap",
		"contact"		=> "Contact"
	],

	"footer" => [
		"contact"		=> "Contact us",
		"madeBy"		=> "Website made by"
	]
];