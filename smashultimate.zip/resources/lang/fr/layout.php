<?php

return [
	"meta" => [
		"description"		=> "Le site de la communauté compétitive française de Super Smash Bros Ultimate.",
		"title"				=> "Le site de la communauté compétitive française"
	],

	"navbar" => [
		"home"				=> "Accueil",
		"calendar"			=> "Planning",
		"vod"				=> "VODs",
		"ranking"			=> "Classement",
		"map"				=> "Mappemonde",
		"contact"			=> "Contacts"
	],

	"footer" => [
		"contact"			=> "Nous contacter",
		"madeBy"			=> "Site internet réalisé par"
	]
];