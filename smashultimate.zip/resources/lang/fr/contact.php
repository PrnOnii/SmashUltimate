<?php

return [
	"title"				=> "L'équipe",
	"role" => [
		"bastien"		=> "Instigateur du projet SmashUltimate.fr",
		"kevan"			=> "Développeur web",
		"jean"			=> "Infographiste / Web designer",
		"remi"			=> "Responsable du planning des tournois",
		"licia"			=> "Chargée de communication | Réseaux Sociaux",
		"arnaud"		=> "Chargé de communication | VODs"
	],
	"description" => [
		"bastien"		=> "Aime jouer à smash, parler de smash, réunir les gens autour de smash et donner des ordres",
		"kevan"			=> "Couteau littéralement suisse de l'équipe et bourreur de shoryus devant l'éternel.",
		"jean"			=> "Ex et futur TO marseillais il est, malgré la faible pluviométrie de sa région, le
							meilleur utilisateur du parapluie de Villageois.",
		"remi"			=> "",
		"licia"			=> "Lilloise et végétarienne, elle est la parfaite remplisseuse de quota minorités.",
		"arnaud"		=> "À la fois présent sur smash, pokken, youtube et twitter il est la face très visible
							de la communauté parisienne (et française)."
	]
];