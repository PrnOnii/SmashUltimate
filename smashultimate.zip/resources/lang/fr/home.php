<?php

return [
	"banner" => [
		"title"			=> "Bienvenue sur SmashUltimate.fr",
		"description"	=> "Le point de rencontre de la communauté compétitive française de Super Smash bros Ultimate."
	],
	"calendar"			=> "Planning rapide",
	"twitter"			=> "Twitter",
	"twitch"			=> "Twitch live"
];