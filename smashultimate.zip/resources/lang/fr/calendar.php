<?php

return [
	"views" => [
		"listMonth"		=> "Liste Mois",
		"listYear"		=> "Liste Année"
	]
];