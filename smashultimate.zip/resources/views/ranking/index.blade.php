@extends("layouts.app")

@section('title')
	Ranking
@endsection

@section("content")
<div class="row">
	<div class="col-12">
		<h3>Ranking Actuel</h3>
		<img src="{{ asset('img/Ranking.jpg') }}" class="img-fluid">
	</div>
</div>
<div class="row">
	<div class="col-12">
		<h3>
			Ruleset et autre conneries du genre
		</h3>
	</div>
</div>
@endsection