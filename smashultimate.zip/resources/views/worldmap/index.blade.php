@extends("layouts.app")

@section('title')
	MappeMonde
@endsection

@section("content")
<div class="row">
	<div class="col-12">
		<h1>To be done</h1>
	</div>
</div>
@endsection