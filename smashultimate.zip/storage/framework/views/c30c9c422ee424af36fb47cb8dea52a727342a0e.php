<!DOCTYPE html>
<html lang="<?php echo e(Session::get("locale", config('app.locale'))); ?>">
<head>
	<link rel="icon" type="image/png" href="<?php echo e(asset("img/favicon-16x16.png")); ?>" sizes="16x16" />
	<link rel="icon" type="image/png" href="<?php echo e(asset("img/favicon-32x32.png")); ?>" sizes="32x32" />
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="<?php echo e(trans('layout.meta.description')); ?>" />
	<meta name="author" content="Onii =D, Volya">
	<meta name="keywords" content="" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<title><?php echo e(config('app.name', 'Smash Ultimate FR')); ?> | <?php echo e(trans('layout.meta.title')); ?></title>

	<!-- CSRF Token -->
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

	<!-- ===== Styles ===== -->
	<!-- Bootstrap core CSS -->
	<link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

	<!-- SmashUltimate.fr Core CSS -->
	<link href="<?php echo e(asset('css/smashultimate.css')); ?>" rel="stylesheet">

	<!-- Datatables -->
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/dt-1.10.18/sl-1.2.6/datatables.min.css"/>

	<!-- Fontawesome 5 -->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">

	<!-- Fullcalendar.js -->
	<link rel='stylesheet' href='<?php echo e(asset('fullcalendar/fullcalendar.css')); ?>'>

	<!-- Flags -->
	<link rel="stylesheet" href="<?php echo e(asset("css/flags/flags.min.css")); ?>">

	<!-- View specific css -->
	<?php echo $__env->yieldContent('styles'); ?>

</head>
<body>

<!-- ====== NAVIGATION ====== -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
	<div class="container">
		<a class="navbar-brand logo" href="<?php echo e(route('home')); ?>"></a>
		<button class="navbar-toggler navbar-toggler-right"
						type="button"
						data-toggle="collapse"
						data-target="#navbarResponsive"
						aria-controls="navbarResponsive"
						aria-expanded="false"
						aria-label="Toggle navigation"
		>
			<span class="navbar-toggler-icon"></span>
		</button>

		<div class="collapse navbar-collapse" id="navbarResponsive">
			<ul class="navbar-nav ml-auto">
				<li class="nav-item <?php echo e(Request::is('/') ? 'active' : ''); ?>">
					<a class="nav-link" href="<?php echo e(route('home')); ?>">
						<i class="fas fa-home"></i> <?php echo e(trans('layout.navbar.home')); ?>

					</a>
				</li>
				<li class="nav-item <?php echo e(Request::is('planning') ? 'active' : ''); ?>">
					<a class="nav-link" href="<?php echo e(route('planning')); ?>">
						<i class="fas fa-calendar-alt"></i> <?php echo e(trans('layout.navbar.calendar')); ?>

					</a>
				</li>
				<li class="nav-item <?php echo e(Request::is('VODs') ? 'active' : ''); ?>">
					<a class="nav-link" href="<?php echo e(route('VOD')); ?>">
						<i class="fas fa-video"></i> <?php echo e(trans('layout.navbar.vod')); ?>

					</a>
				</li>
				<li class="nav-item <?php echo e(Request::is('ranking') ? 'active' : ''); ?>">
					<a class="nav-link" href="<?php echo e(route('ranking')); ?>">
						<i class="fas fa-trophy"></i> <?php echo e(trans('layout.navbar.ranking')); ?>

					</a>
				</li>
				<li class="nav-item <?php echo e(Request::is('worldmap') ? 'active' : ''); ?>">
					<a class="nav-link" href="<?php echo e(route('worldmap')); ?>">
						<i class="fas fa-globe"></i> <?php echo e(trans('layout.navbar.map')); ?>

					</a>
				</li>
				<li class="nav-item <?php echo e(Request::is('contact') ? 'active' : ''); ?>">
					<a class="nav-link" href="<?php echo e(route('contact')); ?>">
						<i class="far fa-user"></i> <?php echo e(trans('layout.navbar.contact')); ?>

					</a>
				</li>
				<li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle"
					   href="#"
					   id="navbarDropdown"
					   role="button"
					   data-toggle="dropdown"
					   aria-haspopup="true"
					   aria-expanded="false"
					>
						<?php echo e(Session::get("locale", config('app.locale'))); ?>

					</a>
					<div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
						<?php $__currentLoopData = config("app.locales"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<a class="dropdown-item" href="<?php echo e(action("HomeController@language", ["lang" => $locale])); ?>">
								<img src="<?php echo e(asset("/img/blank.gif")); ?>" class="flag flag-<?php echo e($locale); ?>"> <?php echo e($locale); ?>

							</a>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</div>
								</li>
							</ul>
						</div>
					</div>
				</nav>


				<!-- ====== BANNER ====== -->
<?php if(Request::is('/')): ?>
<section id="banner">
	<h2><?php echo e(trans("home.banner.title")); ?></h2>
	<p><?php echo e(trans("home.banner.description")); ?></p>
</section>
<?php endif; ?>

<?php if(false): ?>
<!-- ====== SESSION FLASH ====== -->
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<?php if(session('confirmation-success')): ?>
				<div class="alert alert-success">
					<?php echo e(session('confirmation-success')); ?>

				</div>
			<?php endif; ?>
			<?php if(session('confirmation-danger')): ?>
				<div class="alert alert-danger">
					<?php echo session('confirmation-danger'); ?>

				</div>
			<?php endif; ?>
			<?php if($errors->any()): ?>
				<div class="alert alert-danger">
					<ul>
						<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li><?php echo e($error); ?></li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
				</div>
			<?php endif; ?>
		</div>
	</div>
</div>
<?php endif; ?>
<!-- ====== MAIN CONTENT ====== -->
<div class="container
						<?php if(!Request::is('/')): ?>
							navspace
						<?php endif; ?>
						">
	<?php echo $__env->yieldContent('content'); ?>
</div>

<!-- ====== FOOTER ====== -->
<footer id="footer">
	<div class="container">
		<div class="copyright">
			<li>&copy; 2018 SmashUltimate.fr</li>
			<li><?php echo e(trans('layout.footer.contact')); ?> :
				<a href="contact@smashultimate.fr">contact@smashultimate.fr</a>
			</li>
			<li><?php echo e(trans('layout.footer.madeBy')); ?>

				<a href="https://twitter.com/PrnOnii">Onii</a> &
				<a href="http://twitter.com/VolyaSSB">Volya</a>
			</li>
		</div>
</footer>

<!-- Scripts -->
<script src="<?php echo e(asset('js/jquery-3.3.1.slim.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script src
="https://unpkg.com/sweetalert2@7.24.1/dist/sweetalert2.all.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/v/bs4/dt-1.10.18/sl-1.2.6/datatables.min.js"></script>
<script src="<?php echo e(asset('js/moment.js')); ?>"></script>
<script src="<?php echo e(asset('js/SmashUltimate.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.2/Chart.bundle.min.js"></script>
<script>
		// $(".chosen").chosen();
</script>
<script src='<?php echo e(asset("fullcalendar/fullcalendar.js")); ?>'></script>
<script src="<?php echo e(asset('fullcalendar/gcal.js')); ?>"></script>
<script src="<?php echo e(asset('fullcalendar/locale-all.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
