<?php $__env->startSection('title'); ?>
	VODs
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<div class="row">
	<div class="col-12">
		<img src="<?php echo e(asset("img/construction.png")); ?>" class="mx-auto d-block mt-5" alt="Under Construction">
		<h3 class="text-center"><?php echo e(trans("home.construction")); ?></h3>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>