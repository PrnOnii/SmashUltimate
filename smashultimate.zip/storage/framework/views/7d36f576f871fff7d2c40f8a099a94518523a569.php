<?php $__env->startSection('title'); ?>
	Ranking
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<div class="row">
	<div class="col-12">
		<h3>Ranking Actuel</h3>
		<img src="<?php echo e(asset('img/Ranking.jpg')); ?>" class="img-fluid">
	</div>
</div>
<div class="row">
	<div class="col-12">
		<h3>
			Ruleset et autre conneries du genre
		</h3>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>