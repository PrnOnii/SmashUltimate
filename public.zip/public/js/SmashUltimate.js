window.onresize = function() {
		console.log("pouet");
	if(window.width < 1200) {
		console.log("pouet");
	}
}